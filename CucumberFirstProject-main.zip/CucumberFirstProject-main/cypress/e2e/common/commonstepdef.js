import {Given,When, Then, And} from "cypress-cucumber-preprocessor/steps"


Given("User open the browser",()=> {
    cy.log("Opening the chrome browser")
})